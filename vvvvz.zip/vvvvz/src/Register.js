import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import { TextField, Button, Typography } from '@mui/material';
const SignUpWrapper = styled('div')(({ theme }) => ({
  margin: 'auto',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#fff',
  padding: theme.spacing(3),
  borderRadius: 4,
  boxShadow: '0px 0px 8px rgba(0, 0, 0, 0.2)',
  margin: theme.spacing(3),
  marginTop: '60px',
}));
const SignUpTitle = styled(Typography)(({ theme }) => ({
  textAlign: 'center',
  marginBottom: theme.spacing(2),
  color: '#000',
  fontWeight: 'bold',
  fontSize: 24,
}));
const SignUpForm = styled('form')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}));
const SignUpInput = styled(TextField)(({ theme }) => ({
  margin: theme.spacing(1),
  width: '100%',
  '& label': {
    color: '#000',
  },
}));
const SignUpButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(2),
  padding: theme.spacing(1),
  width: '80%',
  borderRadius: 20,
  background: 'linear-gradient(to right, #FFF, #000)',
  boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  fontWeight: 'bold',
  color: '#000',
  '&:hover': {
    background: 'linear-gradient(to right, #000, #FFF)',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  },
}));
const Register = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [passwordRepeat, setPasswordRepeat] = useState('');
  const [agree, setAgree] = useState(false);
  const handleSignUp = () => {
    if (!username || !password || !passwordRepeat || !agree) {
      alert('请填写完整信息并同意注册规则');
      return;
    }
    if (password !== passwordRepeat) {
      alert('两次输入的密码不一致');
      return;
    }
    // 注册成功，跳转到登录页面
    navigate('/login');
  };
  return (
    <SignUpWrapper>
      <SignUpTitle>Sign Up</SignUpTitle>
      <SignUpForm>
        <SignUpInput label="Username" variant="outlined" required value={username} onChange={(e) => setUsername(e.target.value)} />
        <SignUpInput label="Password" type="password" variant="outlined" required value={password} onChange={(e) => setPassword(e.target.value)} />
        <SignUpInput label="Repeat Password" type="password" variant="outlined" required value={passwordRepeat} onChange={(e) => setPasswordRepeat(e.target.value)} />
        <label>
          <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
          Agree to the registration rules
        </label>
        <SignUpButton onClick={handleSignUp}>Sign Up</SignUpButton>
      </SignUpForm>
    </SignUpWrapper>
  );
};
export default Register