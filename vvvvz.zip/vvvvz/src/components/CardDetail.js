import "../Main.css";

function CardDetail(props) {
  const { id, title, content, image, contentDetail, alt } = props.cardInfo;

  if (!props.cardInfo) {
    return null;
  }

  function handleBackClick() {
    props.onCloseClick();
  }

  return (
    <div className="detail-container">
      <div className="card-image">
        <img src={image} alt={alt} />
      </div>
      <div className="card-content">
        <h2>{title}</h2>
        <p>{contentDetail}</p>
        <button onClick={handleBackClick}>返回</button>
      </div>
    </div>
  );
}

  
  export default CardDetail;
  