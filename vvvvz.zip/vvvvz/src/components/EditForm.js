import React, { useState } from 'react';

import "../Main.css";

function EditForm({ cardData, onSaveClick, onCloseClick }) {
  const { title, content } = cardData;
  const [updatedTitle, setUpdatedTitle] = useState(title);
  const [updatedContent, setUpdatedContent] = useState(content);

  function handleTitleChange(e) {
    setUpdatedTitle(e.target.value);
  }

  function handleContentChange(e) {
    setUpdatedContent(e.target.value);
  }

  function handleSaveClick() {
    onSaveClick({
      ...cardData,
      title: updatedTitle,
      content: updatedContent,
    });
  }

  function handleCloseClick() {
    onCloseClick();
  }

  return (
    <div className="edit-container">
      <form className="edit-form">
        <label>
          标题：
          <input type="text" value={updatedTitle} onChange={handleTitleChange} />
        </label>
        <label>
          内容：
          <textarea value={updatedContent} onChange={handleContentChange} />
        </label>
        <div className="edit-form-buttons">
          <button type="button" onClick={handleSaveClick}>保存</button>
          <button type="button" onClick={handleCloseClick}>关闭</button>
        </div>
      </form>
    </div>
  );
}

export default EditForm;
