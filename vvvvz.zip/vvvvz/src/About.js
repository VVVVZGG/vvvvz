import * as React from 'react';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import { NavLink } from 'react-router-dom';

import { Button, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions } from "@mui/material";


import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

import "./Main.css";
import logo from '../src/components/logologin.jpg'
import { useState } from "react";

import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
// import p4 from '../src/components/img1.jpg';
import img1 from '../src/components/img1.jpg';
import img2 from '../src/components/img1.jpg';
import img3 from '../src/components/img1.jpg';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';


  

function useWelcomePopup() {
    const [showPopup, setShowPopup] = useState(false);
    function togglePopup() {
      setShowPopup(!showPopup);
    }
    return [showPopup, togglePopup];
  }
  function About() {
    const [showWelcome, toggleWelcome] = useWelcomePopup();

    const [open, setOpen] = useState(false);

    const handleClickOpen = () => {
      setOpen(true);
    };
  
    const handleClose = () => {
      setOpen(false);
    };

    function handleUserAvatarClick() {
      toggleWelcome();
    }
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        cssEase: "linear",
        arrows: false,
      };


 

    return (


        <div className="main-container">
       <header className="main-header">
  <div className="main-header-nav-links">
    <NavLink exact to="/home">Home</NavLink>
    <NavLink to="/main">Main</NavLink>
    <NavLink to="/about">About</NavLink>
  </div>
  <img src={logo} alt="Your Logo" className="main-header-logo" />
  <div className="main-header-user-info">
    <div className="main-header-user-name">Username</div>
    <img
      src="https://placehold.it/50x50"
      alt="User Avatar"
      className="main-header-user-avatar"
      onClick={handleUserAvatarClick}
    />
    {showWelcome && (
      <div className="welcome-popup">
        <p>Welcome!</p>
        <button onClick={toggleWelcome}>Logout</button>
      </div>
    )}
  </div>
</header>



     

        <h1>这是关于页面:</h1>

        <Box sx={{ width: '100%', maxWidth: 500, margin: 'auto', marginTop: 5  }}>
      <Typography variant="subtitle1" sx={{textAlign: 'center'}} gutterBottom>
        subtitle1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur
      </Typography>
      <Typography variant="subtitle2" sx={{textAlign: 'center'}} gutterBottom>
        subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur
      </Typography>
      <Typography variant="body1" sx={{textAlign: 'center'}} gutterBottom>
        body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur unde suscipit, quam beatae rerum inventore consectetur,
        neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti? Eum
        quasi quidem quibusdam.
      </Typography>
      <Typography variant="body2" sx={{textAlign: 'center'}} gutterBottom>
        body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur unde suscipit, quam beatae rerum inventore consectetur,
        neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti? Eum
        quasi quidem quibusdam.
      </Typography>
      <Typography variant="button" sx={{textAlign: 'center'}} display="block" gutterBottom>
        button text
      </Typography>
      <Typography variant="caption" sx={{textAlign: 'center'}} display="block" gutterBottom>
        caption text
      </Typography>
      <Typography variant="overline" sx={{textAlign: 'center'}} display="block" gutterBottom>
        overline text
      </Typography>
    </Box>

    
    <h3>联系我们：</h3>
<p>地址：XXX市XXX区XXX路XXX号XXX大厦XXX室</p>
<p>电话：XXX-XXXXXXX</p>
<p>邮箱：contact@yourcompany.com</p>



        
    




        <footer className="main-footer">
          <p>© Your Company Name</p>
        </footer>
      </div>
    );
            }
  
  export default About;