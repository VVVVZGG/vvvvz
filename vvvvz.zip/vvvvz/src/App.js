import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Login';
import Main from './main';
import Home from './Home';
import About from './About';
import User from './User';
// import Register from './Register';
function App() {
  return (
 <Router>
      <Routes>
      <Route exact path="/main" element={<Main />} />
      <Route exact path="/" element={<Login/>} />
        {/* <Route path="/register" element={<Register />} /> */}
        <Route exact path="/home" element={<Home/>} />
        <Route exact path="/about" element={<About/>} />
        <Route exact path="/user" element={<User/>} />
       
      </Routes>
    </Router>
  );
}

export default App;
