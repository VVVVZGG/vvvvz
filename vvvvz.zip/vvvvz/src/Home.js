import * as React from 'react';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import { NavLink } from 'react-router-dom';


import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

import "./Main.css";
import logo from '../src/components/logologin.jpg'
import { useState } from "react";

import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
// import p4 from '../src/components/img1.jpg';
import img1 from '../src/components/img1.jpg';
import img2 from '../src/components/img1.jpg';
import img3 from '../src/components/img1.jpg';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';



function useWelcomePopup() {
    const [showPopup, setShowPopup] = useState(false);
    function togglePopup() {
      setShowPopup(!showPopup);
    }
    return [showPopup, togglePopup];
  }
  function Home() {
    const [showWelcome, toggleWelcome] = useWelcomePopup();

    function handleUserAvatarClick() {
      toggleWelcome();
    }
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        cssEase: "linear",
        arrows: false,
      };

      
function srcset(image, size, rows = 1, cols = 1) {
    return {
      src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
      srcSet: `${image}?w=${size * cols}&h=${
        size * rows
      }&fit=crop&auto=format&dpr=2 2x`,
    };
  }

  const itemData = [
    {
        img: 'https://images.unsplash.com/photo-1551963831-b3b1ca40c98e',
        title: 'Breakfast',
        rows: 2,
        cols: 2,
      },
      {
        img: 'https://images.unsplash.com/photo-1551782450-a2132b4ba21d',
        title: 'Burger',
      },
      {
        img: 'https://images.unsplash.com/photo-1522770179533-24471fcdba45',
        title: 'Camera',
      },
      {
        img: 'https://images.unsplash.com/photo-1444418776041-9c7e33cc5a9c',
        title: 'Coffee',
        cols: 2,
      },
      {
        img: 'https://images.unsplash.com/photo-1533827432537-70133748f5c8',
        title: 'Hats',
        cols: 2,
      },
      {
        img: 'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62',
        title: 'Honey',
        author: '@arwinneil',
        rows: 2,
        cols: 2,
      },
      {
        img: 'https://images.unsplash.com/photo-1516802273409-68526ee1bdd6',
        title: 'Basketball',
      },
      {
        img: 'https://images.unsplash.com/photo-1518756131217-31eb79b20e8f',
        title: 'Fern',
      },
  ];
  
 

    return (


        <div className="main-container">
       <header className="main-header">
  <div className="main-header-nav-links">
    <NavLink exact to="/home">Home</NavLink>
    <NavLink to="/main">Main</NavLink>
    <NavLink to="/about">About</NavLink>
  </div>
  <img src={logo} alt="Your Logo" className="main-header-logo" />
  <div className="main-header-user-info">
    <div className="main-header-user-name">Username</div>
    <img
      src="https://placehold.it/50x50"
      alt="User Avatar"
      className="main-header-user-avatar"
      onClick={handleUserAvatarClick}
    />
    {showWelcome && (
      <div className="welcome-popup">
        <p>Welcome!</p>
        <button onClick={toggleWelcome}>Logout</button>
      </div>
    )}
  </div>
</header>

        <div>
          <Slider {...settings}>
            <div>
              <img src={img1} alt="Carousel Image 1" />
            </div>
            <div>
              <img src={img2} alt="Carousel Image 2" />
            </div>
            <div>
              <img src={img3} alt="Carousel Image 3" />
            </div>
          </Slider>
        </div>

        <Box sx={{ width: '100%', maxWidth: 500, margin: 'auto', marginTop: 5  }}>
      <Typography variant="subtitle1" sx={{textAlign: 'center'}} gutterBottom>
        subtitle1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur
      </Typography>
      <Typography variant="subtitle2" sx={{textAlign: 'center'}} gutterBottom>
        subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur
      </Typography>
      <Typography variant="body1" sx={{textAlign: 'center'}} gutterBottom>
        body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur unde suscipit, quam beatae rerum inventore consectetur,
        neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti? Eum
        quasi quidem quibusdam.
      </Typography>
      <Typography variant="body2" sx={{textAlign: 'center'}} gutterBottom>
        body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos
        blanditiis tenetur unde suscipit, quam beatae rerum inventore consectetur,
        neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti? Eum
        quasi quidem quibusdam.
      </Typography>
      <Typography variant="button" sx={{textAlign: 'center'}} display="block" gutterBottom>
        button text
      </Typography>
      <Typography variant="caption" sx={{textAlign: 'center'}} display="block" gutterBottom>
        caption text
      </Typography>
      <Typography variant="overline" sx={{textAlign: 'center'}} display="block" gutterBottom>
        overline text
      </Typography>
    </Box>



        <ImageList
      sx={{ width: '100%', height: 750 }}
      variant="quilted"
      cols={4}
      rowHeight={121}
    >
      {itemData.map((item) => (
        <ImageListItem key={item.img} cols={item.cols || 1} rows={item.rows || 1}>
          <img
            {...srcset(item.img, 121, item.rows, item.cols)}
            alt={item.title}
            loading="lazy"
          />
        </ImageListItem>
      ))}
    </ImageList>


    
        
    

    



   


        <footer className="main-footer">
          <p>© Your Company Name</p>
        </footer>
      </div>
    );
            }
  
  export default Home;