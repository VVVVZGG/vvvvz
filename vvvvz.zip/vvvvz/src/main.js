import React from "react";
import "./Main.css";
import { NavLink } from 'react-router-dom';
import logo from '../src/components/logologin.jpg'
import { useState } from "react";
import p1 from '../src/components/p.png';
import p2 from '../src/components/8.png';
import p3 from '../src/components/p2.png';
import EditForm from "./components/EditForm";
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
// import p4 from '../src/components/img1.jpg';
import img1 from '../src/components/img1.jpg';
import img2 from '../src/components/img1.jpg';
import img3 from '../src/components/img1.jpg';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Register from "./Register";

import CardDetail from "./components/CardDetail";


const DATA = [
  {
    id: 1,
    title: 'Column 1',
    content: '查看详情',
    image: p1,
    contentDetail: '这是第1个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 2,
    title: 'Column 2',
    content: 'Content goes here',
    image: p2,
    contentDetail: '这是第2个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 3,
    title: 'Column 3',
    content: 'Content goes here',
    image: p3,
    contentDetail: '这是第3个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 4,
    title: 'Column 4',
    content: 'Content goes here',
    image: p2,
    contentDetail: '这是第4个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 5,
    title: 'Column 5',
    content: 'Content goes here',
    image: p1,
    contentDetail: '这是第5个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
    
  },
  {
    id: 6,
    title: 'Column 6',
    content: 'Content goes here',
    image: p2,
    contentDetail: '这是第6个卡片的详情信息',
    alt: 'Alternative Text',
  },
  {
    id: 7,
    title: 'Column 7',
    content: 'Content goes here',
    image: p1,
    contentDetail: '这是第7个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 8,
    title: 'Column 8',
    content: 'Content goes here',
    image: p2,
    contentDetail: '这是第8个卡片的详情信息:',
    
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 9,
    title: 'Column 9',
    content: 'Content goes here',
    image: p3,
    contentDetail: '这是第1个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 10,
    title: 'Column 10',
    content: 'Content goes here',
    image: p1,
    contentDetail: '这是第1个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 11,
    title: 'Column 11',
    content: 'Content goes here',
    image: p2,
    contentDetail: '这是第1个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
  {
    id: 12,
    title: 'Column 12',
    content: 'Content goes here',
    image: p3,
    contentDetail: '这是第12个卡片的详情信息',
    alt: 'Alternative Text',
    company: "MNO Company",
    phone: "777-888-9999",
    salary: "250,000",
  },
];

function useWelcomePopup() {
  const [showPopup, setShowPopup] = useState(false);
  function togglePopup() {
    setShowPopup(!showPopup);
  }
  return [showPopup, togglePopup];
}
function Main() {
  const [showWelcome, toggleWelcome] = useWelcomePopup();
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedCard, setSelectedCard] = useState(null);
  const [showEditForm, setShowEditForm] = useState(false);
  const [cards, setCards] = useState(DATA);
  const [selectedCardDetail, setSelectedCardDetail] = useState(null);
  function handleUserAvatarClick() {
    toggleWelcome();
  }
  function handlePrevClick() {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  }
  function handleNextClick() {
    if (currentPage < Math.ceil(DATA.length / 6)) {
      setCurrentPage(currentPage + 1);
    }
  }
  function handleDetailClick(id) {
    const selectedCard = cards.find((item) => item.id === id);
    setSelectedCard(null);
    setSelectedCardDetail(selectedCard);
  }
  function handleCloseClick() {
    setSelectedCardDetail(null);
  }
  function handleBackClick() {
    setSelectedCard(null);
    setSelectedCardDetail(null);
  }
  function handleEditClick(id) {
    const selectedCardIndex = cards.findIndex((item) => item.id === id);
    setSelectedCard(cards[selectedCardIndex]);
    setShowEditForm(true);
  }
  function handleDeleteClick(id) {
    setCards(cards.filter((item) => item.id !== id));
  }
  function handleSubmit(event) {
    event.preventDefault();
    const updatedCards = [...cards];
    const cardIndex = updatedCards.findIndex(
      (item) => item.id === selectedCard.id
    );
    updatedCards[cardIndex] = {
      ...selectedCard,
      company: event.target.company.value,
      phone: event.target.phone.value,
      salary: event.target.salary.value,
    };
    setCards(updatedCards);
    setShowEditForm(false);
  }

  return (
    <div className="main-container">
     <header className="main-header">
  <div className="main-header-nav-links">
    <NavLink exact to="/home">Home</NavLink>
    <NavLink to="/main">Main</NavLink>
    <NavLink to="/about">About</NavLink>
  </div>
  <img src={logo} alt="Your Logo" className="main-header-logo" />
  <div className="main-header-user-info">
    <div className="main-header-user-name">Username</div>
    <img
      src="https://placehold.it/50x50"
      alt="User Avatar"
      className="main-header-user-avatar"
      onClick={handleUserAvatarClick}
    />
    {showWelcome && (
      <div className="welcome-popup">
        <p>Welcome!</p>
        <button onClick={toggleWelcome}>Logout</button>
      </div>
    )}
  </div>
</header>

      <main className="main-content">
        {!selectedCardDetail ? (
          !selectedCard ? (
            <>
              {cards
                .slice((currentPage - 1) * 6, currentPage * 6)
                .map((item) => (
                  <div className="main-column" key={item.id}>
                    <img src={item.image} alt={item.alt} />
                    <h2>{item.title}</h2>
                    <p onClick={() => handleDetailClick(item.id)}>
                      {item.content}
                    </p>
                    <div className="card-buttons">
                      <button>
                        编辑
                      </button>
                      <button onClick={() => handleDeleteClick(item.id)}>
                        删除
                      </button>
                    </div>
                  </div>
                ))}
              <div className="pagination">
                <button
                  onClick={handlePrevClick}
                  disabled={currentPage === 1}
                >
                  上一页
                </button>
                <button
                  onClick={handleNextClick}
                  disabled={currentPage === Math.ceil(DATA.length / 6)}
                >
                  下一页
                </button>
              </div>
            </>
          ) : (
            <div className="detail-container">
              {/* if (!selectedCardDetail) {
  return null;
} */}
              <img src={selectedCardDetail.image} alt={selectedCardDetail.alt} />
              <div className="card-details">
                <h2>{selectedCardDetail.title}</h2>
                <p>{selectedCardDetail.content}</p>
              </div>
              <button onClick={handleBackClick}>返回</button>
            </div>
          )
        ) : (
          <CardDetail cardInfo={selectedCardDetail} onCloseClick={handleCloseClick} />
        )}
        {showEditForm && (
          <div className="edit-form-container">
            <h2>编辑表单</h2>
            <form onSubmit={handleSubmit}>
              <label htmlFor="company">公司：</label>
              <input
                type="text"
                id="company"
                name="company"
                defaultValue={selectedCard.company}
              />
              <br />
              <label htmlFor="phone">电话：</label>
              <input
                type="text"
                id="phone"
                name="phone"
                defaultValue={selectedCard.phone}
              />
              <br />
              <label htmlFor="salary">薪资：</label>
              <input
                type="text"
                id="salary"
                name="salary"
                defaultValue={selectedCard.salary}
              />
              <br />
              <button type="submit">保存</button>
              <button onClick={() => setShowEditForm(false)}>取消</button>
            </form>
          </div>
        )}
      </main>
      <footer className="main-footer">
        <p>© Your Company Name</p>
      </footer>
    </div>
  );
}



export default Main;