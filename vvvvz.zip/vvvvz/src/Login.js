
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Container, Typography, Link } from '@mui/material';
// import { styled } from '@mui/material/styles';
import Modal from '@mui/material/Modal'
import styled from '@mui/material/styles/styled';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';




const Wrapper = styled('div')(({ theme }) => ({


  minHeight: '95.5vh',
  display: 'flex',
  flexDirection: 'column',
  backgroundColor: '#f8f9fa',
  padding: theme.spacing(),
  backgroundImage: 'url(../img1.jpg)',
  backgroundPosition: 'center',
  backgroundSize: 'cover'
}));

const HeaderWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(4),
  margin: theme.spacing(), // 添加margin
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundPosition: 'center',
  backgroundSize: 'cover',
}));

const Title = styled(Typography)(({ theme }) => ({
  color: '#fff',
  textShadow: '1px 1px 1px rgba(0,0,0,0.5)',
  fontWeight: 'bold',
}));

const LoginWrapper = styled('div')(({ theme }) => ({
  margin: 'auto',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#fff',
  padding: theme.spacing(3),
  borderRadius: 4,
  boxShadow: '0px 0px 8px rgba(0, 0, 0, 0.2)',
  margin: theme.spacing(3), // 添加margin
  marginTop: '60px', // 添加 marginTop 属性
}));

const LoginTitle = styled(Typography)(({ theme }) => ({
  textAlign: 'center',
  marginBottom: theme.spacing(2),
  color: '#000',
  fontWeight: 'bold',
  fontSize: 24,
}));

const Form = styled('form')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}));

const FormInput = styled(TextField)(({ theme }) => ({
  margin: theme.spacing(1),
  width: '100%',
  '& label': {
    color: '#000',
  },
}));

// const LoginButton = styled(Button)(({ theme }) => ({
//   margin: theme.spacing(2),
//   padding: theme.spacing(1),
//   width: '80%',
//   borderRadius: 20,
//   background: 'linear-gradient(to right, #FFF, #000)',
//   boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
//   fontWeight: 'bold',
//   color: '#000',
//   '&:hover': {
//     background: 'linear-gradient(to right, #000, #FFF)',
//     boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
//   },
// }));

const LoginButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(1),
  padding: theme.spacing(1),
  width: '70%',
  height: '40px',
  borderRadius: 20,
  background: 'linear-gradient(to right, #FFF, #000)',
  boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  fontWeight: 'bold',
  color: '#000',
  '&:hover': {
    background: 'linear-gradient(to right, #000, #FFF)',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  },
}));

const SignUpButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(1),
  padding: theme.spacing(1),
  width: '80%',
  height: '40px',
  borderRadius: 20,
  background: 'linear-gradient(to right, #FFF, #000)',
  boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  fontWeight: 'bold',
  color: '#000',
  '&:hover': {
    background: 'linear-gradient(to right, #000, #FFF)',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  },
}));


const SignUpLink = styled(Link)(({ theme }) => ({
  textAlign: 'center',
  color: '#000',
  fontWeight: 'bold',
  fontSize: 16,
}));

const Footer = styled('footer')(({ theme }) => ({
  // backgroundColor: '#fff', // 修改页脚的背景色为白色
  color: '#fff', // 修改页脚文字颜色为黑色
  textAlign: 'center',
  fontSize: 14,
  padding: theme.spacing(5),
  marginTop: 'auto',
  height: 40, 
}));

const ModalWrapper = styled('div')(({ theme }) => ({
  backgroundColor: '#fff',
  padding: theme.spacing(3),
  borderRadius: 4,
  boxShadow: '0px 0px 8px rgba(0, 0, 0, 0.2)',
  outline: 'none',
  display: 'flex',
  flexDirection: 'column',
}));

const ModalTitle = styled(Typography)(({ theme }) => ({
  textAlign: 'center',
  marginBottom: theme.spacing(2),
  color: '#000',
  fontWeight: 'bold',
  fontSize: 24,
}));

const ModalForm = styled(Form)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}));

const ModalFormInput = styled(FormInput)(({ theme }) => ({
  margin: theme.spacing(1),
}));

const ModalFormButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(1),
  padding: theme.spacing(1),
  width: '100%',
  borderRadius: 20,
  background: 'linear-gradient(to right, #FFF, #000)',
  boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  fontWeight: 'bold',
  color: '#000',
  '&:hover': {
    background: 'linear-gradient(to right, #000, #FFF)',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
  },
}));


function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [openModal, setOpenModal] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [repeatPassword, setRepeatPassword] = useState('');
  const [agreeRules, setAgreeRules] = useState(false);

  const handleLogin = () => {
    if (username === 'admin' && password === '123') {
      navigate('/home');
    }
    else if(username === 'user' && password === '1234'
    ){
      navigate('/user');
    }
     else {
      alert('用户名或密码错误');
    }
  };

  
  const handleSignUp = () => {
    if (newUsername.length < 6 || newPassword.length < 6) {
      alert('账号和密码必须至少6个字符');
      return;
    }
    if (newPassword !== repeatPassword) {
      alert('密码和确认密码不匹配');
      return;
    }
    if (!agreeRules) {
      alert('请同意注册规则');
      return;
    }

    // 处理注册逻辑
    alert('注册成功！');
    setOpenModal(false);
  };

  return (
    <Wrapper>
      <HeaderWrapper>
        <Title variant="h4">Vehicle Management System</Title>
      </HeaderWrapper>
      <Container maxWidth="sm" component="main">
        <LoginWrapper>
          <LoginTitle variant="h5">Log In</LoginTitle>
          <Form>
            <FormInput label="Username" variant="outlined" required value={username} onChange={(e) => setUsername(e.target.value)} />
            <FormInput label="Password" type="password" variant="outlined" required value={password} onChange={(e) => setPassword(e.target.value)} />
            <div style={{ display: 'flex', flexDirection: 'row' }}>
              <LoginButton variant="contained" onClick={handleLogin}>登录</LoginButton>
              <SignUpButton variant="contained" onClick={() => setOpenModal(true)}>注册</SignUpButton>
            </div>
            <SignUpLink href="#" variant="body2">
              Don't have an account yet? Sign Up
            </SignUpLink>
          </Form>
          <Modal open={openModal} onClose={() => setOpenModal(false)}>
            <ModalWrapper>
              <ModalTitle>Sign Up</ModalTitle>
              <ModalForm>
                <ModalFormInput label="Username" variant="outlined" required value={newUsername} onChange={(e) => setNewUsername(e.target.value)} />
                <ModalFormInput label="Password" type="password" variant="outlined" required value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
                <ModalFormInput label="Repeat Password" type="password" variant="outlined" required value={repeatPassword} onChange={(e) => setRepeatPassword(e.target.value)} />
                <label>
                  <input type="checkbox" checked={agreeRules} onChange={(e) => setAgreeRules(e.target.checked)} />
                  &nbsp;I agree to the rules of registration
                </label>
                <ModalFormButton variant="contained" onClick={handleSignUp}>Sign Up</ModalFormButton>
              </ModalForm>
            </ModalWrapper>
          </Modal>
        </LoginWrapper>
      </Container>
      <Footer>
        &copy; 2022 Vehicle Management System. All rights reserved.
      </Footer>
    </Wrapper>
  );
}

export default Login;


