import { dividerClasses } from '@mui/material';
import React from 'react';

// import Register from './Register';
function User() {
  return (
<div>
    这是User页面。
</div>

  );
}

export default User;